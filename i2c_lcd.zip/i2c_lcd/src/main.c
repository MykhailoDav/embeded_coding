#include "i2c.h"
#include "usart.h"
#include "lcd.h"

void uart_print(const char *s)
{
    while (*s)
        USART_PutChar(*s++);
}

int main(void)
{
    USART_Init(9600);
    USART_SetStdStreams();

    I2C_Init();

    uart_print("Scanning I2C devices...\r\n");
    I2C_ScanConnectedDevices(uart_print);

    uart_print("\r\nInitializing LCD...\r\n");

    if (LCD_Init(LCD_ADDR) == 0)
    {
        uart_print("LCD OK\r\n");

        LCD_Clear();
        LCD_Print(0, 0, "Hello, World!");
        LCD_Print(0, 1, "I2C LCD Ready");
    }
    else
    {
        uart_print("LCD NOT FOUND!\r\n");
    }

    while (1)
    {
        USART_poll();
    }
}
